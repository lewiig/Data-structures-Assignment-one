# Data-Structures-Assignment
Group assignment  BBIT/2025/40521
Data structures are classified into two main branches:
Linear Data Structures
Linear data structures store elements in a sequential order. Each element is connected to the next in a single line.
Types of Linear Data Structures:
Array
An array is a collection of elements of the same data type stored in contiguous memory locations. It allows fast access using an index. Arrays are used in storing marks, managing lists, and image processing.
Linked List
A linked list consists of nodes stored in non-contiguous memory locations. Each node contains data and a pointer to the next node. It is useful when frequent insertion and deletion are required.
Stack
A stack follows the Last In First Out (LIFO) principle. Elements are added and removed from one end called the top. It is used in function calls, undo/redo operations, and expression evaluation.
Queue
A queue follows the First In First Out (FIFO) principle. Elements are inserted at the rear and removed from the front. It is used in process scheduling and printer task management.
Non-Linear Data Structures
Non-linear data structures store elements in a hierarchical or network form rather than a straight sequence.
Types of Non-Linear Data Structures:
Tree
A tree is a hierarchical structure consisting of nodes connected by edges. It has a root node and child nodes. Trees are used in file systems, databases, and decision-making systems.
Graph
A graph consists of vertices (nodes) connected by edges. It is used to represent networks such as social media connections, maps, and communication networks.

